import time
import os

while True:
	os.system('python a.py')
	time.sleep(60)

